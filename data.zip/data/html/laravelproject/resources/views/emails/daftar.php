<p>Hi, Kamu, Iya Kamu!</p>
<p>Ini adalah contoh body email nya ya.... </p>